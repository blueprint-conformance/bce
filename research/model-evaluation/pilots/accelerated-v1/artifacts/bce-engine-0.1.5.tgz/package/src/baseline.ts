/**
 * `bce baseline` — the shrink-only, PR-reviewable adoption lever (SPEC §9.3).
 *
 * The complementary adoption posture to advisory mode (§9.2). Where advisory ungates the WHOLE
 * verdict's exit while surfacing everything, baseline keeps the gate ENFORCING but measures it
 * against a recorded pre-existing violation set: a NEW violation always fails the build; a
 * BASELINED violation is reported (visible, counted, never hidden) but does not block; a violation
 * that DISAPPEARS is auto-removed the next time the baseline is written. Neither posture suppresses
 * a new violation — advisory prints it (and the score still shrinks), baseline still FAILS on it.
 *
 * The one load-bearing invariant, executable in tests/baseline.test.ts:
 *
 *   THE FILE ONLY EVER SHRINKS.
 *
 * A `bce baseline` write against an EXISTING baseline can only produce a SUBSET of the entries
 * that were in it: entries whose violation still exists are kept, entries whose violation vanished
 * are dropped, and a violation NOT already baselined is REFUSED entry (never silently added). To
 * GROW the baselined set you must delete the file and re-create it — a PR-visible act. This is the
 * widen-only ratchet (§10.3, "gates tighten, never silently relax") applied to the burndown wall:
 * the wall of accepted debt can only come down, and any attempt to raise it is a reviewed change.
 *
 * Identity is CONTENT-ADDRESSED so a violation is the SAME violation across runs regardless of
 * scan revision or wall-clock: `sha256(blueprintRef \x00 constraintId \x00 component)` — the exact
 * tuple `evaluate` sorts violations by (constraintId, component), scoped by the blueprint that
 * produced it. Two violations with the same (blueprint, constraint, component) are one identity;
 * a violation that moves to a new component or constraint is a NEW identity (correctly un-baselined).
 * The `observed`/`expected`/`evidenceRef` strings (which carry a line number and can drift on an
 * unrelated edit) are deliberately NOT part of the identity — baselining a violation must survive a
 * line shift, or the wall would spuriously re-redden on formatting.
 */
import { createHash } from 'node:crypto';
import * as fs from 'node:fs';
import * as path from 'node:path';
import type { ComplianceReport, Violation } from './report.js';
import { stableStringify } from './report.js';

/** The canonical baseline file, committed beside the blueprints (a PR-reviewed FILE, never a flag). */
export const BASELINE_BASENAME = 'baseline.json';
/** The in-repo baseline path, relative to the repo root. */
export const BASELINE_RELPATH = path.join('.blueprints', BASELINE_BASENAME);

/** The current baseline-file schema version (its own, independent of the report schema). */
export const BASELINE_SCHEMA_VERSION = '1';

/** Raised on a malformed baseline.json — fail-closed: a corrupt baseline never silently grades. */
export class BaselineError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'BaselineError';
  }
}

/**
 * One baselined violation identity. The `id` is the content-address; the human-legible fields
 * (`blueprintRef`, `constraintId`, `component`, `severity`) are carried so the committed file is
 * PR-reviewable without re-running the engine — a reviewer reads exactly which violation on which
 * component under which blueprint is being accepted, and at what severity.
 */
export interface BaselineEntry {
  /** `sha256(blueprintRef \x00 constraintId \x00 component)` — the stable violation identity. */
  id: string;
  blueprintRef: string;
  constraintId: string;
  component: string;
  severity: Violation['severity'];
}

/** The baseline file shape: schema version, the engine that wrote it, and the sorted entry set. */
export interface BaselineFile {
  schemaVersion: string;
  /** The engine version that wrote this baseline (provenance; never used to re-grade). */
  engine: string;
  /** Baselined identities, sorted by `id` (byte-stable). */
  entries: BaselineEntry[];
}

/**
 * The content-address for a violation, scoped by the blueprint that produced it. This is the ONLY
 * place the identity is defined — every consumer (write, diff, gate-partition) derives from here so
 * the identity can never drift between the writer and the reader (consume-don't-duplicate).
 */
export function violationIdentity(blueprintRef: string, v: Pick<Violation, 'constraintId' | 'component'>): string {
  return createHash('sha256').update(`${blueprintRef}\0${v.constraintId}\0${v.component}`).digest('hex');
}

/** Build a `BaselineEntry` from a report's blueprintRef + one of its violations. */
function entryOf(blueprintRef: string, v: Violation): BaselineEntry {
  return {
    id: violationIdentity(blueprintRef, v),
    blueprintRef,
    constraintId: v.constraintId,
    component: v.component,
    severity: v.severity,
  };
}

/** Sort entries by their content-address id (the byte-stable order). */
function sortEntries(entries: BaselineEntry[]): BaselineEntry[] {
  return [...entries].sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}

/** Serialize a baseline file canonically (recursively sorted keys, 2-space indent, trailing newline). */
export function serializeBaseline(file: BaselineFile): string {
  return stableStringify({ ...file, entries: sortEntries(file.entries) });
}

/** Does a repo carry a committed baseline file? */
export function baselineExists(repoDir: string): boolean {
  return fs.existsSync(path.join(repoDir, BASELINE_RELPATH));
}

/**
 * Read + STRICT-parse the committed baseline. ABSENT → null (the caller decides: gate treats a
 * null baseline as "enforce everything", write treats it as a fresh creation). A PRESENT-but-
 * malformed file is a `BaselineError` (fail-closed — a corrupt baseline must never silently grade
 * as an empty one, which would re-redden every accepted violation, nor as a permissive one).
 */
export function readBaseline(repoDir: string): BaselineFile | null {
  const p = path.join(repoDir, BASELINE_RELPATH);
  if (!fs.existsSync(p)) return null;
  let raw: unknown;
  try {
    raw = JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (e) {
    throw new BaselineError(`${BASELINE_RELPATH} is not valid JSON: ${(e as Error).message}`);
  }
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    throw new BaselineError(`${BASELINE_RELPATH} must be a JSON object`);
  }
  const obj = raw as Record<string, unknown>;
  if (typeof obj.schemaVersion !== 'string') {
    throw new BaselineError(`${BASELINE_RELPATH} is missing a string "schemaVersion"`);
  }
  if (typeof obj.engine !== 'string') {
    throw new BaselineError(`${BASELINE_RELPATH} is missing a string "engine"`);
  }
  if (!Array.isArray(obj.entries)) {
    throw new BaselineError(`${BASELINE_RELPATH} is missing an "entries" array`);
  }
  const entries: BaselineEntry[] = [];
  const seen = new Set<string>();
  for (const [i, e] of obj.entries.entries()) {
    if (typeof e !== 'object' || e === null || Array.isArray(e)) {
      throw new BaselineError(`${BASELINE_RELPATH} entries[${i}] must be an object`);
    }
    const en = e as Record<string, unknown>;
    for (const k of ['id', 'blueprintRef', 'constraintId', 'component', 'severity'] as const) {
      if (typeof en[k] !== 'string' || (en[k] as string).length === 0) {
        throw new BaselineError(`${BASELINE_RELPATH} entries[${i}] is missing a non-empty string "${k}"`);
      }
    }
    const id = en.id as string;
    // integrity: the stored id MUST equal the content-address of its own fields — a hand-edited
    // entry that changed the constraint/component but kept an old id (to smuggle a broader identity
    // past the shrink-only write) is a hard error, never a silent accept.
    const recomputed = violationIdentity(en.blueprintRef as string, {
      constraintId: en.constraintId as string,
      component: en.component as string,
    });
    if (id !== recomputed) {
      throw new BaselineError(
        `${BASELINE_RELPATH} entries[${i}] id does not match its (blueprintRef, constraintId, component) — the baseline was hand-edited inconsistently`,
      );
    }
    if (seen.has(id)) {
      throw new BaselineError(`${BASELINE_RELPATH} entries[${i}] duplicates id ${id.slice(0, 12)}…`);
    }
    seen.add(id);
    entries.push({
      id,
      blueprintRef: en.blueprintRef as string,
      constraintId: en.constraintId as string,
      component: en.component as string,
      severity: en.severity as BaselineEntry['severity'],
    });
  }
  return { schemaVersion: obj.schemaVersion, engine: obj.engine, entries: sortEntries(entries) };
}

/** The set of every violation identity across a run's reports (the "current" violation set). */
export function currentIdentities(reports: readonly ComplianceReport[]): Set<string> {
  const ids = new Set<string>();
  for (const r of reports) {
    for (const v of r.violations) ids.add(violationIdentity(r.blueprintRef, v));
  }
  return ids;
}

/**
 * Partition a run's violations against a baseline, per report. The result drives BOTH the gate's
 * fail/pass decision and its BASELINED accounting:
 *
 *  - `newViolations`: violations whose identity is NOT in the baseline. These ALWAYS fail the gate
 *    (a baseline never suppresses a new violation — SPEC §9.3).
 *  - `baselinedViolations`: violations whose identity IS in the baseline. Reported (visible,
 *    counted) but non-blocking.
 *
 * A null baseline (no file) means "nothing is accepted": every violation is new (byte-identical to
 * the pre-baseline gate — widen-only). The partition NEVER mutates the report's score or verdict;
 * it is an overlay the gate reads to decide the EXIT, exactly as advisory mode overlays the exit.
 */
export interface BaselinePartition {
  blueprintRef: string;
  newViolations: Violation[];
  baselinedViolations: Violation[];
}

export function partitionAgainstBaseline(
  reports: readonly ComplianceReport[],
  baseline: BaselineFile | null,
): BaselinePartition[] {
  const accepted = new Set(baseline?.entries.map((e) => e.id) ?? []);
  return reports.map((r) => {
    const newViolations: Violation[] = [];
    const baselinedViolations: Violation[] = [];
    for (const v of r.violations) {
      const id = violationIdentity(r.blueprintRef, v);
      if (accepted.has(id)) baselinedViolations.push(v);
      else newViolations.push(v);
    }
    return { blueprintRef: r.blueprintRef, newViolations, baselinedViolations };
  });
}

/** The outcome of computing what a `bce baseline` write WOULD produce (for messaging + the write). */
export interface BaselineWritePlan {
  /** true when a baseline file already existed (→ shrink-only); false = fresh creation. */
  hadExisting: boolean;
  /** The entries that will be written (sorted). */
  entries: BaselineEntry[];
  /** ADDED (fresh-creation only — always empty on a shrink write). */
  added: BaselineEntry[];
  /** KEPT (present in both the old baseline and the current violation set). */
  kept: BaselineEntry[];
  /** REMOVED (were in the old baseline, but the violation has since disappeared → auto-removed). */
  removed: BaselineEntry[];
  /**
   * REFUSED (current NEW violations a shrink write did NOT add — present now, not in the old
   * baseline). On a shrink write these are surfaced so the operator knows what a re-baseline would
   * NOT accept; to accept them, delete the file and re-create. Always empty on a fresh creation.
   */
  refused: BaselineEntry[];
}

export type BaselineCheckState = 'clean' | 'shrink-needed' | 'unaccepted-new' | 'refusal';

export interface BaselineCheckResult {
  schemaVersion: '1';
  state: BaselineCheckState;
  baselineActive: boolean;
  currentViolations: number;
  kept: number;
  removable: number;
  unacceptedNew: number;
  refusalReasons: string[];
  exitCode: 0 | 1 | 2;
}

/** Typed maintenance outcome; callers never infer readiness from human prose. */
export function assessBaselineMaintenance(
  reports: readonly ComplianceReport[],
  existing: BaselineFile | null,
  refusalReasons: readonly string[] = [],
): { result: BaselineCheckResult; plan: BaselineWritePlan } {
  const plan = planBaselineWrite(reports, existing);
  const reportRefusals = reports
    .filter((r) => r.verdict !== 'pass' && r.violations.length === 0)
    .map((r) => r.summary);
  const reasons = [...new Set([...refusalReasons, ...reportRefusals])];
  const currentViolations = reports.reduce((n, r) => n + r.violations.length, 0);
  let state: BaselineCheckState;
  let exitCode: 0 | 1 | 2;
  if (reasons.length > 0) {
    state = 'refusal';
    exitCode = 2;
  } else if (existing === null && currentViolations > 0) {
    state = 'unaccepted-new';
    exitCode = 1;
  } else if (plan.refused.length > 0) {
    state = 'unaccepted-new';
    exitCode = 1;
  } else if (plan.removed.length > 0) {
    state = 'shrink-needed';
    exitCode = 1;
  } else {
    state = 'clean';
    exitCode = 0;
  }
  return {
    result: {
      schemaVersion: '1',
      state,
      baselineActive: existing !== null,
      currentViolations,
      kept: plan.kept.length,
      removable: plan.removed.length,
      unacceptedNew: existing === null ? plan.added.length : plan.refused.length,
      refusalReasons: reasons,
      exitCode,
    },
    plan,
  };
}

/**
 * A deterministic whole-file unified patch for a shrink plan. Refuses fresh creation and any plan
 * whose target is not a subset of the prior identity set. The patch may remove debt only.
 */
export function renderBaselineShrinkPatch(existing: BaselineFile, plan: BaselineWritePlan): string {
  if (!plan.hadExisting) throw new BaselineError('cannot render a shrink patch for fresh baseline creation');
  const prior = new Set(existing.entries.map((e) => e.id));
  if (plan.entries.some((e) => !prior.has(e.id))) {
    throw new BaselineError('refused to render baseline patch: target contains an identity absent from the prior baseline');
  }
  const before = serializeBaseline(existing).trimEnd().split('\n');
  const after = serializeBaseline({ ...existing, entries: plan.entries }).trimEnd().split('\n');
  if (before.join('\n') === after.join('\n')) return '';
  return [
    `--- a/${BASELINE_RELPATH}`,
    `+++ b/${BASELINE_RELPATH}`,
    `@@ -1,${before.length} +1,${after.length} @@`,
    ...before.map((line) => `-${line}`),
    ...after.map((line) => `+${line}`),
    '',
  ].join('\n');
}

/**
 * Compute what a `bce baseline` write produces. This is the shrink-only heart:
 *
 *  - FRESH CREATION (no existing baseline): the plan's entries are EVERY current violation. This is
 *    the only path that can grow the accepted set, and it is PR-visible (a new file appears).
 *  - SHRINK WRITE (an existing baseline): the plan's entries are the INTERSECTION of the existing
 *    baselined identities with the current violation set — kept if the violation still exists,
 *    dropped (auto-removed) if it vanished. A current violation NOT already baselined is REFUSED
 *    (never added). The result is therefore always a SUBSET of the prior baseline.
 *
 * Pure — it reads the prior baseline + the current reports and returns the plan; the caller writes.
 */
export function planBaselineWrite(
  reports: readonly ComplianceReport[],
  existing: BaselineFile | null,
): BaselineWritePlan {
  // current violations, de-duplicated to one entry per identity (the same identity can only be
  // baselined once; the FIRST report carrying it wins the human-legible fields deterministically
  // because reports + violations are already sorted upstream).
  const currentById = new Map<string, BaselineEntry>();
  for (const r of reports) {
    for (const v of r.violations) {
      const en = entryOf(r.blueprintRef, v);
      if (!currentById.has(en.id)) currentById.set(en.id, en);
    }
  }
  const currentIds = new Set(currentById.keys());

  if (existing === null) {
    // FRESH CREATION — accept every current violation (the one growth path, PR-visible).
    const entries = sortEntries([...currentById.values()]);
    return { hadExisting: false, entries, added: entries, kept: [], removed: [], refused: [] };
  }

  // SHRINK WRITE — keep only prior entries whose violation still exists; drop the rest; refuse new.
  const priorById = new Map(existing.entries.map((e) => [e.id, e]));
  const kept: BaselineEntry[] = [];
  const removed: BaselineEntry[] = [];
  for (const e of existing.entries) {
    if (currentIds.has(e.id)) kept.push(e);
    else removed.push(e);
  }
  const refused: BaselineEntry[] = [];
  for (const [id, en] of currentById) {
    if (!priorById.has(id)) refused.push(en);
  }
  return {
    hadExisting: true,
    entries: sortEntries(kept),
    added: [],
    kept: sortEntries(kept),
    removed: sortEntries(removed),
    refused: sortEntries(refused),
  };
}

/**
 * Write the baseline file for a repo per a computed plan. Returns the absolute path written.
 * Creates `.blueprints/` if absent. Serialized canonically (byte-stable). This is the ONLY mutation
 * in the module; everything above is pure so the plan can be previewed/asserted before the write.
 */
export function writeBaseline(repoDir: string, plan: BaselineWritePlan, engine: string): string {
  const p = path.join(repoDir, BASELINE_RELPATH);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  const file: BaselineFile = {
    schemaVersion: BASELINE_SCHEMA_VERSION,
    engine,
    entries: plan.entries,
  };
  fs.writeFileSync(p, serializeBaseline(file));
  return p;
}
